# -*- coding: utf-8 -*-
"""
NnBim: SCANNER RAIO-X GLOBAL (VERSÃO TURBO)
DESCRICAO:
Extrai ABSOLUTAMENTE todos os parâmetros, incluindo:
- Parâmetros Nativos (Built-in)
- Parâmetros de Projeto
- Parâmetros Compartilhados (Shared Parameters)
"""

__title__ = 'Raio-X\nGlobal'
__author__ = 'NnBim Dev'

from pyrevit import revit, forms, script
from Autodesk.Revit.DB import *

doc = revit.doc
uidoc = revit.uidoc
output = script.get_output()

def main():
    selection = uidoc.Selection.GetElementIds()
    
    el = None
    el_type = None
    contexto = ""
    
    # 1. LÓGICA DE DECISÃO
    if selection:
        if len(selection) > 1:
            forms.alert("Selecione apenas UM elemento para um Raio-X preciso.")
            return
            
        el = doc.GetElement(selection[0])
        contexto = "Elemento Selecionado"
        
        if el.GetTypeId() != ElementId.InvalidElementId:
            el_type = doc.GetElement(el.GetTypeId())
            
    else:
        opcoes = {
            "Informações do Projeto": doc.ProjectInformation,
            "Vista / Prancha Atual": doc.ActiveView
        }
        
        escolha = forms.SelectFromList.show(
            opcoes.keys(), 
            title="O que deseja escanear?",
            multiselect=False
        )
        
        if not escolha: return
        el = opcoes[escolha]
        contexto = escolha

    # 2. CABEÇALHO
    output.print_md("# 🚀 Raio-X NnBim: Scanner Global (Deep Scan)")
    output.print_md("### Copie tudo e mande para o seu Engenheiro Sénior (IA)")
    output.print_md("---")
    
    # 3. FUNÇÃO DE EXTRAÇÃO DE PARÂMETROS (MELHORADA)
    def print_parameters(element, title):
        output.print_md("## " + title)
        
        # .GetOrderedParameters() é o segredo para pegar Parâmetros Compartilhados!
        all_params = element.GetOrderedParameters()
        
        if not all_params:
            print("*Nenhum parâmetro encontrado.*")
            return

        # Ordenar por nome
        sorted_params = sorted(all_params, key=lambda p: p.Definition.Name)

        for p in sorted_params:
            try:
                nome = p.Definition.Name
                # Verifica se é compartilhado
                is_shared = " (COMPARTILHADO)" if p.IsShared else ""
                
                # Valor do parâmetro
                valor = "N/A"
                if p.StorageType == StorageType.String:
                    valor = p.AsString()
                else:
                    valor = p.AsValueString()
                
                if valor is None or valor == "": valor = "[Vazio]"
                
                # Identificação técnica
                bip = p.Definition.BuiltInParameter
                if bip != BuiltInParameter.INVALID:
                    cod = str(bip)
                else:
                    # Se for compartilhado, mostra o GUID (Identidade única dele)
                    cod = "GUID: " + str(p.GUID) if p.IsShared else "Customizado"

                print("🔹 Nome: **{}{}** | Valor: `{}` | Código: `{}`".format(nome, is_shared, valor, cod))
            except Exception as e:
                continue

    # 4. IMPRESSÃO
    print("- Categoria: {}".format(el.Category.Name if el.Category else "N/A"))
    print("- Nome: {}".format(el.Name))
    print("- ID: {}".format(el.Id))
    
    output.print_md("---")
    print_parameters(el, "🛠️ PARÂMETROS DE INSTÂNCIA")
    
    if el_type:
        output.print_md("---")
        print_parameters(el_type, "🏢 PARÂMETROS DE TIPO")
        
    output.print_md("---")
    output.print_md("**Scanner Concluído. Dê Ctrl+A, Ctrl+C e mande no chat.**")

if __name__ == '__main__':
    main()