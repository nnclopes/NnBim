# -*- coding: utf-8 -*-
"""
NnBim: GESTOR DE TITULOS E ORDEM DE DESENHO
------------------------------------------------------------
DESCRICAO:
Sincroniza nomes de vistas (Navegador e Folha) e a ordem 
dos detalhes com as gavetas do carimbo (DESENHO 01-17).

COMO USAR:
1. Altere o 'Nome da Vista' para renomear no Navegador.
2. Altere o 'Titulo na Folha' para mudar o texto no carimbo.
3. Altere o 'No Det.' para reordenar a lista no carimbo.
------------------------------------------------------------
"""

__title__ = 'Titulo das\nVistas'
__author__ = 'NnBim Dev'

import os
import re
from pyrevit import forms, revit, script
from Autodesk.Revit.DB import *

doc = revit.doc

# --- CLASSE DE DADOS ---
class VistaData(object):
    def __init__(self, view_id, vp_id, sheet_id, prancha_num, num_detalhe, nome_vista, titulo_atual):
        self.ViewId = view_id
        self.ViewportId = vp_id
        self.SheetId = sheet_id
        self.Prancha = prancha_num
        self.NumeroDetalhe = num_detalhe
        self.NomeVista = nome_vista # Editavel na tabela
        self.TituloFolha = titulo_atual if titulo_atual else "" # Editavel na tabela

# --- MOTOR DE ATUALIZACAO DO CARIMBO ---
def atualizar_carimbo_desenhos(sheet):
    viewports = [doc.GetElement(vpid) for vpid in sheet.GetAllViewports()]
    dados_vistas = []

    for vp in viewports:
        view = doc.GetElement(vp.ViewId)
        if view.ViewType in [ViewType.Legend, ViewType.Schedule]: 
            continue

        num = vp.get_Parameter(BuiltInParameter.VIEWPORT_DETAIL_NUMBER).AsString()
        tit_param = view.get_Parameter(BuiltInParameter.VIEW_DESCRIPTION).AsString()
        
        # Logica NnBim: Prioriza Titulo, senao usa Nome da Vista
        nome_final = tit_param if (tit_param and tit_param.strip()) else view.Name
        
        dados_vistas.append({
            'ordem': int(num) if (num and num.isdigit()) else 99,
            'texto': nome_final.upper()
        })

    # Ordena pelo numero do detalhe
    dados_vistas.sort(key=lambda x: x['ordem'])

    # Preenche os parametros DESENHO 01 ate 17
    for i in range(1, 18):
        p_nome = "DESENHO {:02d}".format(i)
        param = sheet.LookupParameter(p_nome)
        if param and not param.IsReadOnly:
            if i <= len(dados_vistas):
                param.Set(dados_vistas[i-1]['texto'])
            else:
                param.Set("")

# --- INTERFACE WPF ---
class JanelaTitulos(forms.WPFWindow):
    def __init__(self, xaml_path, lista_dados):
        forms.WPFWindow.__init__(self, xaml_path)
        self.dgVistas.ItemsSource = lista_dados

    def salvar_titulos(self, sender, e):
        self.Close()
        lista = self.dgVistas.ItemsSource
        sheets_afetadas = list(set([item.SheetId for item in lista]))

        # TRANSACOES
        with revit.Transaction("NnBim: Atualizar Vistas"):
            # 1. Renomear e ajustar titulos
            for item in lista:
                view = doc.GetElement(item.ViewId)
                vp = doc.GetElement(item.ViewportId)
                
                # ATUALIZA NOME DA VISTA (Navegador)
                try:
                    if view.Name != item.NomeVista:
                        view.Name = item.NomeVista
                except Exception:
                    # Se falhar (ex: nome duplicado), ele ignora e continua
                    pass
                
                # ATUALIZA TITULO NA FOLHA
                val_tit = item.TituloFolha.strip() if item.TituloFolha else ""
                view.get_Parameter(BuiltInParameter.VIEW_DESCRIPTION).Set(val_tit.upper())
                
                # Numero detalhe temporario (evita erro de duplicidade no Revit)
                if item.NumeroDetalhe:
                    vp.get_Parameter(BuiltInParameter.VIEWPORT_DETAIL_NUMBER).Set("temp_" + str(item.NumeroDetalhe))

            # 2. Numero detalhe definitivo
            for item in lista:
                if item.NumeroDetalhe:
                    vp = doc.GetElement(item.ViewportId)
                    vp.get_Parameter(BuiltInParameter.VIEWPORT_DETAIL_NUMBER).Set(str(item.NumeroDetalhe))

        # 3. Sincroniza parametros do carimbo
        with revit.Transaction("NnBim: Sync Carimbo"):
            for s_id in sheets_afetadas:
                atualizar_carimbo_desenhos(doc.GetElement(s_id))

        forms.toast("Nomes, Titulos e Carimbos Sincronizados!")

# --- EXECUCAO ---
def main():
    sheets = FilteredElementCollector(doc).OfClass(ViewSheet).ToElements()
    sheet_dict = {s.SheetNumber + " - " + s.Name: s for s in sheets}
    
    sel = forms.SelectFromList.show(
        sorted(sheet_dict.keys()), 
        multiselect=True, 
        title="Gestao de Titulos: Selecione as Pranchas",
        button_name="Analisar Vistas"
    )
    
    if not sel: 
        script.exit()

    vistas_dados = []
    for p_nome in sel:
        sheet = sheet_dict[p_nome]
        for vpid in sheet.GetAllViewports():
            vp = doc.GetElement(vpid)
            v = doc.GetElement(vp.ViewId)
            
            # Pula tabelas e legendas (nao tem Detail Number padrao)
            if v.ViewType in [ViewType.Legend, ViewType.Schedule]: 
                continue
            
            num = vp.get_Parameter(BuiltInParameter.VIEWPORT_DETAIL_NUMBER).AsString()
            tit = v.get_Parameter(BuiltInParameter.VIEW_DESCRIPTION).AsString()
            
            vistas_dados.append(VistaData(v.Id, vp.Id, sheet.Id, sheet.SheetNumber, num, v.Name, tit))

    if vistas_dados:
        # Busca o XAML na mesma pasta do script
        xaml = os.path.join(os.path.dirname(__file__), "GerirTitulos.xaml")
        JanelaTitulos(xaml, vistas_dados).ShowDialog()
    else:
        forms.alert("Nenhuma vista encontrada nas pranchas selecionadas.")

if __name__ == '__main__':
    main()