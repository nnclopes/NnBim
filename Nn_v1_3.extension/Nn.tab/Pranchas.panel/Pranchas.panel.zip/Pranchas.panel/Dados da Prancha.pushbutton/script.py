# -*- coding: utf-8 -*-
"""
NnBim: GESTOR DE DADOS DO CARIMBO
------------------------------------------------------------
DESCRICAO: 
Atualiza dados nativos e compartilhados (Disciplina da Prancha)
em múltiplas folhas simultaneamente.

AUTOR: NnBim Dev
VERSAO: 4.5 (Estavel - Sem Acentos)
------------------------------------------------------------
"""

__title__ = 'Dados da\nPrancha'
__author__ = 'NnBim'

import sys
import os
import re
from Autodesk.Revit.DB import *
from pyrevit import forms, revit, script

# --- BUSCA DINAMICA DA PASTA LIB (Sobe ate achar) ---
def achar_lib():
    caminho_atual = os.path.dirname(__file__)
    for _ in range(10):
        check_path = os.path.join(caminho_atual, 'lib')
        if os.path.exists(check_path):
            return check_path
        caminho_atual = os.path.dirname(caminho_atual)
    return None

lib_path = achar_lib()
if lib_path:
    xaml_path = os.path.join(lib_path, 'GUI', 'GestorPranchas.xaml')
    if lib_path not in sys.path:
        sys.path.append(lib_path)
else:
    forms.alert("Erro: Pasta lib nao encontrada.")
    script.exit()

import wpf
from System.IO import StringReader

# --- CLASSE DA INTERFACE ---
class JanelaPranchas(forms.WPFWindow):
    def __init__(self, xaml_file_path):
        try:
            # Leitura binaria para evitar erro de caracteres estranhos
            with open(xaml_file_path, 'rb') as f:
                raw = f.read()
                if raw.startswith(b'\xef\xbb\xbf'):
                    raw = raw[3:]
                layout = raw.decode('utf-8', 'ignore')
            wpf.LoadComponent(self, StringReader(layout))
        except Exception as e:
            forms.alert("Erro ao carregar XAML: " + str(e))
            
        self._carregar_pranchas()

    def _carregar_pranchas(self):
        """Lista pranchas em ordem natural"""
        sheets = FilteredElementCollector(revit.doc).OfClass(ViewSheet).ToElements()
        def natural_sort(s):
            return [int(t) if t.isdigit() else t.lower() for t in re.split('([0-9]+)', s.SheetNumber)]
        sorted_sheets = sorted(sheets, key=natural_sort)
        self.lbPranchas.ItemsSource = [s.SheetNumber + " - " + s.Name for s in sorted_sheets]

    def selecionar_todas(self, sender, e):
        self.lbPranchas.SelectAll()

    def fechar_janela(self, sender, e):
        self.Close()

    def ir_para_dados(self, sender, e):
        if not self.lbPranchas.SelectedItems:
            forms.alert("Selecione as pranchas na lista!")
            return
        self.MainTabControl.SelectedIndex = 1

    def executar_atualizacao(self, sender, e):
        selecionados = self.lbPranchas.SelectedItems
        
        # Dados coletados da UI
        d = {
            "des": self.txtDesenhado.Text,
            "proj": self.txtProjetado.Text,
            "ver": self.txtVerificado.Text,
            "disc": self.txtDisciplina.Text, # Valor para 'Disciplina da Prancha'
            "emiss": self.txtDataEmissao.Text,
            "rev": self.txtRevisao.Text,
            "d_rev": self.txtDataRevisao.Text,
            "fase": self.txtFase.Text
        }

        self.Close()

        with revit.Transaction("NnBim: Gestor Prancha"):
            # 1. ATUALIZA INFO DO PROJETO (GLOBAL)
            info = revit.doc.ProjectInformation
            if d["fase"]: 
                p_fase = info.get_Parameter(BuiltInParameter.PROJECT_STATUS)
                if p_fase: p_fase.Set(d["fase"])
            if d["emiss"]:
                p_emiss = info.get_Parameter(BuiltInParameter.PROJECT_ISSUE_DATE)
                if p_emiss: p_emiss.Set(d["emiss"])

            # 2. ATUALIZA CADA FOLHA SELECIONADA
            with forms.ProgressBar(title='NnBim: Gravando dados...') as pb:
                for idx, item in enumerate(selecionados):
                    num = item.split(" - ")[0]
                    sheet = next(s for s in FilteredElementCollector(revit.doc).OfClass(ViewSheet) if s.SheetNumber == num)
                    
                    # Parametros Nativos
                    sheet.get_Parameter(BuiltInParameter.SHEET_DRAWN_BY).Set(d["des"])
                    sheet.get_Parameter(BuiltInParameter.SHEET_DESIGNED_BY).Set(d["proj"])
                    sheet.get_Parameter(BuiltInParameter.SHEET_CHECKED_BY).Set(d["ver"])
                    
                    # Parametros Compartilhados / Customizados
                    # Aqui estao as variacoes de nome para garantir que funcione
                    mapa_custom = {
                        "Disciplina da Prancha": d["disc"], 
                        "Disciplina": d["disc"],
                        "Revisao": d["rev"],
                        "Data da revisao atual": d["d_rev"]
                    }
                    
                    for nome_param, valor in mapa_custom.items():
                        if not valor: continue
                        
                        param_alvo = None
                        # Busca na Folha
                        p_f = sheet.LookupParameter(nome_param)
                        if p_f:
                            param_alvo = p_f
                        else:
                            # Busca no Carimbo (TitleBlock)
                            tbs = FilteredElementCollector(revit.doc, sheet.Id).OfCategory(BuiltInCategory.OST_TitleBlocks)
                            for tb in tbs:
                                p_tb = tb.LookupParameter(nome_param)
                                if p_tb:
                                    param_alvo = p_tb
                                    break
                        
                        # Se achou e puder escrever, grava
                        if param_alvo and not param_alvo.IsReadOnly:
                            param_alvo.Set(valor)
                    
                    pb.update_progress(idx + 1, len(selecionados))
        
        forms.toast("Carimbos Atualizados com Sucesso!")

if __name__ == '__main__':
    JanelaPranchas(xaml_path).ShowDialog()